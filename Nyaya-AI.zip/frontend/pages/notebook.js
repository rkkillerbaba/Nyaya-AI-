export default function Notebook() {
  return (
    <div style={{ padding: 20 }}>
      <h1>AI Notebook (Mock LLM Chat)</h1>
      <p>Chat with Nyaya-AI here (mock implementation).</p>
    </div>
  );
}
